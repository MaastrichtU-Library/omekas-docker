const r={get(e){return this.refs[e]},refs:{},set(e,s){this.refs[e]=s}};export{r as O};
